<?php

/**

* Amped Apps 

* - Custom Meta Fields

*

**/



class AaCustomMetaField_AboutUs extends AaCustomMetaField {



	public $fields = array(
	
			
			'enabled'			=> array('type'=>'select', 'args' => ['values' => ['Yes','No']], 'label' => 'Enable'),
            'main_title'		=> array('type'=>'text', 'label' => 'Main Title'),
            'principal_image'	=> array('type'=>'image', 'args'=> array('width'=>185,'height'=> 222),'label'=>'Principal Image'),
            'principal_name'	=> array('type'=>'text', 'label' => 'Principal Name'),
            'title'				=> array('type'=>'text', 'label' => 'Title'),			
			'message'	    	=> array('type'=>'fullrichText', 'label' => 'Message'),
            'link'			    => array('type'=>'link'),
			'link_text'			=> array('type'=>'linkText', 'label' => 'Link Text'),
			'target'		    => array('type'=>'linkTarget', 'label' => 'Open Link in New Window', 'args' => array('values' => array('No','Yes'))),

           

        );



	public function render()

	{

		$this->getForm($this->fields);

	}



}