<?php

/**

* Amped Apps 

* - Custom Meta Fields

*

**/



class AaCustomMetaField_Promo3 extends AaCustomMetaField {



	public $fields = array(
			'enabled'			=> array('type'=>'select', 'args' => ['values' => ['Yes','No']], 'label' => 'Enable'),
	
			'title'			 => array('type'=>'text', 'label' => 'Title'),

			'title_link'			 => array('type'=>'link', 'label' => 'Title Link'),
			
			'text'	    => array('type'=>'fullrichText', 'label' => 'Promo Text'),
			
			'file'	    => array('type'=>'file', 'label' => 'File'),
			
			'file_name'	    => array('type'=>'text', 'label' => 'File Name'),

			'file_icon'	=> array('type'=>'image', 'args'=> array('width'=>20,'height'=> 20),'label'=>'File Icon'),

			'read_more'			 => array('type'=>'text', 'label' => 'Read More'),

			'read_more_link'			 => array('type'=>'link', 'label' => 'Read More Link'),

    );



	public function render()

	{

		$this->getForm($this->fields);

	}



}