<?php

/**

* Amped Apps 

* - Custom Meta Fields

*

**/



class AaCustomMetaField_Promo4 extends AaCustomMetaField {



	public $fields = array(
			'enabled'			=> array('type'=>'select', 'args' => ['values' => ['Yes','No']], 'label' => 'Enable'),
	
			'title'			 => array('type'=>'text', 'label' => 'Title'),

			/*'title_link'			 => array('type'=>'link', 'label' => 'Title Link'),*/
			
			'text'	    => array('type'=>'fullrichText', 'label' => 'Promo Text'),
			
			'promo_date'	    => array('type'=>'text', 'label' => 'Date'),
			
			'promo_time'	    => array('type'=>'text', 'label' => 'Time'),

			'image'	=> array('type'=>'image', 'args'=> array('width'=>488,'height'=> 488),'label'=>'Image'),

			'read_more'			 => array('type'=>'text', 'label' => 'Read More'),

			'read_more_link'			 => array('type'=>'link', 'label' => 'Read More Link'),

    );



	public function render()

	{

		$this->getForm($this->fields);

	}



}