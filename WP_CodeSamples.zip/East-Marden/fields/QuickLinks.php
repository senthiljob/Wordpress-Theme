<?php
/**
* Amped Apps 
* - Custom Meta Fields
*
**/

class AaCustomMetaField_Quicklinks extends AaCustomMetaField {
	public $fields = array(
            'image'			=> array('type'=>'image', 'args'=> array('width'=>71,'height'=> 62),'label'=>'Logo'),
            'link_text'		=> array('type'=>'text', 'label'=>"Link Text"),
            'link'			          => array('type'=>'link'),
			'target'		          => array('type'=>'linkTarget', 'label' => 'Open Link in New Window', 'args' => array('values' => array('No','Yes'))),
        );
	public function render()
	{
		$this->getForm($this->fields);
	}
}