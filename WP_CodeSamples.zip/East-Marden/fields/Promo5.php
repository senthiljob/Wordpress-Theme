<?php

/**

* Amped Apps 

* - Custom Meta Fields

*

**/



class AaCustomMetaField_Promo5 extends AaCustomMetaField {



	public $fields = array(
			'enabled'			=> array('type'=>'select', 'args' => ['values' => ['Yes','No']], 'label' => 'Enable'),
	
			'title'			 => array('type'=>'text', 'label' => 'Title'),
			
			'text'	    => array('type'=>'fullrichText', 'label' => 'Promo Text'),
			
			'image'	=> array('type'=>'image', 'args'=> array('width'=>620,'height'=> 490),'label'=>'Image'),

			'read_more'			 => array('type'=>'text', 'label' => 'Read More'),

			'read_more_link'			 => array('type'=>'link', 'label' => 'Read More Link'),

    );



	public function render()

	{

		$this->getForm($this->fields);

	}



}