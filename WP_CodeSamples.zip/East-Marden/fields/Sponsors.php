<?php
/**
* Amped Apps 
* - Custom Meta Fields
*
**/

class AaCustomMetaField_Sponsors extends AaCustomMetaField {
	public $fields = array(
            'image'			=> array('type'=>'image', 'args'=> array('height'=> 80),'label'=>'Logo'),
            'link'			          => array('type'=>'link'),
			'target'		          => array('type'=>'linkTarget', 'label' => 'Open Link in New Window', 'args' => array('values' => array('No','Yes'))),
        );
	public function render()
	{
		$this->getForm($this->fields);
	}
}