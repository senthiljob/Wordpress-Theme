<?php

/**

* Amped Apps 

* - Custom Meta Fields

*

**/



class AaCustomMetaField_Promo1 extends AaCustomMetaField {



	public $fields = array(
			'enabled'			=> array('type'=>'select', 'args' => ['values' => ['Yes','No']], 'label' => 'Enable'),
	
			'title'			 => array('type'=>'text', 'label' => 'Title'),
			
			'text'	    => array('type'=>'staticText', 'label' => 'Promo Text'),
			
			'program1'	    => array('type'=>'text', 'label' => 'Program 1'),

			'program1_image'	=> array('type'=>'image', 'args'=> array('width'=>21,'height'=> 21),'label'=>'Image'),
			
			'program2'	    => array('type'=>'text', 'label' => 'Program 2'),

			'program2_image'	=> array('type'=>'image', 'args'=> array('width'=>21,'height'=> 21),'label'=>'Image'),
			
			'program3'	    => array('type'=>'text', 'label' => 'Program 3'),

			'program3_image'	=> array('type'=>'image', 'args'=> array('width'=>21,'height'=> 21),'label'=>'Image'),

    );



	public function render()

	{

		$this->getForm($this->fields);

	}



}