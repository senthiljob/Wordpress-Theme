jQuery(document).ready(function($){
    //

   // $.cookie("pop_viewed", 0, { expires : 1 });   
//alert($.cookie("pop_viewed"));

/*$('#recipeCarousel').carousel({
  interval: 10000
})*/

    $("#top_promo_close").on("click",function(){
        $(".yellow_header_top").addClass("pop_hide");
        var date = new Date();
         //var minutes = 30;
         date.setTime(date.getTime() + (24 * 60 * 60 * 1000));
        $.cookie("pop_viewed", 1, { expires : null }); 
               
        return;
    });
//$.cookie("pop_viewed",0, { expires : null }); 
    if($.cookie("pop_viewed")!="1"){
        $(".yellow_header_top").removeClass("pop_hide");
    }else{
        $(".yellow_header_top").addClass("pop_hide");
    }

    $(".banner_arrow").click(function() {
        $('html, body').animate({
            scrollTop: $("#learning").offset().top
        }, 2000);
    });

    $(".header_search_icon").click(function(){
        $(".search_box,.search_outer_bg").show();
        $(".nav .showmenu ").hide();
    });

    $(".search_outer_bg").click(function(){
        $(".search_box,.search_outer_bg").hide();
    });

    $(window).scroll(function () {
        var myheader = $('.header_bottom_bg'),
            scroll = $(window).scrollTop(),headerfixed = $(".header_bg");
        var myheader_height = myheader.height();
        $(".menu_icon").removeClass("menu_act");
        if (scroll >= myheader_height) {
            headerfixed.addClass('fixed');
            $(".fixed .menu_box").hide();
        } else {
            headerfixed.removeClass('fixed');
            $(".menu_box").show();
        }
    });

    $(".navbar-toggle").on("click",function(){
        var $this = $(this);
        var menutext =  $(".menu");
        if(menutext.hasClass("showmenu")){
            menutext.removeClass("showmenu");
            $this.removeClass("act");
        }else {
            menutext.addClass("showmenu");
            $this.addClass("act");

            $(".menu ul li").click( function(){
                $(".menu ul li").removeClass("current");
                menutext.removeClass("showmenu");
                $(".moblie_menu").removeClass("act");
                $(this).addClass("current");
            });
        }

        $(".search_box").hide();
     });

    $(".bottom_up_arrow_box").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 500);
    });
    
     window.sr = ScrollReveal();
    sr.reveal('.left', {
        origin: 'left',
        duration: 2000,
        distance: '150px',
        mobile: false,
        reset: false
    });

    $('html,body').smoothScroll();
/*
    sr.reveal('.right', {
        origin: 'right',
        duration: 2000,
        distance: '150px',
        mobile: false,
        reset: false
    });

    sr.reveal('.top', {
        origin: 'top',
        duration: 2000,
        distance: '50px',
        mobile: false,
        reset: false
    });

    sr.reveal('.bottom', {
        origin: 'top',
        duration: 2000,
        distance: '-150px',
        mobile: false,
        reset: false
    });  */
//$.fn.cycle.defaults.autoSelector = ".slideshow2";

$('.logoSlider').cycle({

            fx: "carousel",
            
            prev:   '#prev',
            next:   '#next',
            timeout: 0,

            speed: 800,

            slides: ">li",

            carouselVisible:4,

            carouselFluid: true,

            log: false

        });


});

function googleTranslateElementInit() {

            new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');

}
