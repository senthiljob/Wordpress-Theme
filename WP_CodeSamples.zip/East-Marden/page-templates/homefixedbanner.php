<?php

/**

 * Template Name: Home Fixed Banner

 *

 * @package WordPress

 * @subpackage AA_Custom_Theme

 * @since AA Custom Theme 1.0

 */



$cm = new AaCustomMeta();



get_header();  

$meta_boxes = get_post_meta($post->ID,'metabox_order',true);
$page_meta_boxes = unserialize($meta_boxes);

?>

    <!-- / home page -->

    <section id="home-page">
       
   
        <div class="bannernouter">
       
        <div id="home-banner">

            <?php

          $meta = $cm->getList($post->ID, 'home_banners', 'HomeBanner'); // post id, custom meta id, custom meta field type

            $config = $meta['__config'];

            unset($meta['__config']);



            $width = isset($config['image']['args']['width']) ? $config['image']['args']['width'] : 1920;

            $height = isset($config['image']['args']['height']) ? $config['image']['args']['height'] : 500;

            if(is_array($meta) && sizeof($meta)):

			  echo '<div class="hidden-xs">';

                echo '<ul id="banner-images" >';

                foreach($meta as $banner):
                    unset($image);

                    $image = '';

                    if(isset($banner['image']) && strlen($banner['image'])):

                        $image = Imulation::open($banner['image'])

                            ->width($width)

                            ->height($height)

                            ->scale(Imulation::FILL)

                            ->crop()
							
							->quality(90)

                            ->save('banner-image')

                            ->filename();

                        $image = $image->url;

                        if(file_exists(ABSPATH.'/'.$image)):



                            $image = AaHelp::checkLink($image);

                            echo '<li style="background-image:url('.$image.')" class="home_banner_list">';

                                    echo"<img src='".$image."'/>";
							echo "<div class='banner_content container nopadding'>";
                          		if($banner['title']!=""){
									echo "<span class='banner_title'>".$banner['title']."</span>";
								}
								
								if($banner['description']!=""){
									echo "<span class='banner_desc'>".$banner['description']."</span>";
								}
								
								if($banner['link_title']!=""){
									$target="";
									if($banner['target']=='Yes'){
										$target = "_blank";
									}
									echo "<a class='banner_link' href='".$banner['link']."' target='".$target."'>".$banner['link_title']."</a>";
								}

							echo "</div>";

                            echo '</li>';

                        endif;

                    endif;

					

                endforeach;

                echo '</ul>';

			echo "</div>";

                ?>

          <?php endif; ?>

          

          <?php // mobile slider

		  if(is_array($meta) && sizeof($meta)):

                $width_mobile = isset($config['mobile_image']['args']['width']) ? $config['mobile_image']['args']['width'] : 600;

                $height_mobile = isset($config['mobile_image']['args']['height']) ? $config['mobile_image']['args']['height'] : 300;

  		        echo '<div class="visible-xs-block hidden-sm hidden-md hidden-lg">';

                echo '<ul id="mobile-banner-images" >';

                foreach($meta as $banner):

                    unset($image);

                    $image = '';

                    if(isset($banner['mobile_image']) && strlen($banner['mobile_image'])):

                        $image = Imulation::open($banner['mobile_image'])

                            ->width($width_mobile)

                            ->height($height_mobile)

                            ->scale(Imulation::FILL)

                            ->crop()

                            ->save('mobile-banner-image')

                            ->filename();

                        $image = $image->url;

                        if(file_exists(ABSPATH.'/'.$image)):



                            $image = AaHelp::checkLink($image);

                            echo '<li style="background-image:url('.$image.')">';



                            echo '<img class="mobile_image" src="'.$image.'"/>';
							
							echo "<div class='banner_content container nopadding'>";
                          		if($banner['title']!=""){
									echo "<span class='banner_title'>".$banner['title']."</span>";
								}
								
								if($banner['description']!=""){
									echo "<span class='banner_desc'>".$banner['description']."</span>";
								}
								
								if($banner['link_title']!=""){
									$target="";
									if($banner['target']=='Yes'){
										$target = "_blank";
									}
									echo "<a class='banner_link' href='".$banner['link']."' target='".$target."'>".$banner['link_title']."</a>";
								}

							echo "</div>";



                            echo '</li>';

                        endif;

                    elseif(isset($banner['image']) && strlen($banner['image'])):

                        $image = Imulation::open($banner['image'])

                            ->width(768)

                            ->height(500)

                            ->scale(Imulation::FILL)

                            ->crop()

                            ->save('mobile-banner-image')

                            ->filename();

                        $image = $image->url;

                        if(file_exists(ABSPATH.'/'.$image)):


                            $image = AaHelp::checkLink($image);

                            echo '<li style="background-image:url('.$image.')">';

								echo '<img class="mobile_image" src="'.$image.'"/>';
	
								echo "<div class='banner_content container nopadding'>";
									if($banner['title']!=""){
										echo "<span class='banner_title'>".$banner['title']."</span>";
									}
									
									if($banner['description']!=""){
										echo "<span class='banner_desc'>".$banner['description']."</span>";
									}
									
									if($banner['link_title']!=""){
										$target="";
										if($banner['target']=='Yes'){
											$target = "_blank";
										}
										echo "<a class='banner_link' href='".$banner['link']."' target='".$target."'>".$banner['link_title']."</a>";
									}
	
								echo "</div>";

                            echo '</li>';

                        endif;

                    endif;

					

                endforeach;

                echo '</ul>';

				echo '</div>';

                ?>

          <?php endif; ?>

          

        </div>

		</div>
        
		<div style="min-height:500px;">
			<?php
                include_once(get_stylesheet_directory().'/homecontent/quicklinks.php');
                include_once(get_stylesheet_directory().'/homecontent/aboutus.php');                
                include_once(get_stylesheet_directory().'/homecontent/newsFeed.php');           
                include_once(get_stylesheet_directory().'/homecontent/specialProgram.php');         
                include_once(get_stylesheet_directory().'/homecontent/enroll-events.php');  
                include_once(get_stylesheet_directory().'/homecontent/studentVoice.php');
            ?>
        </div>
    </section>

<?php get_footer();

