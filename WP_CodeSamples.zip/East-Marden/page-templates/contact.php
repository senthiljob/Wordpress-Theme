<?php

/**

 * Template Name: Contact

 *

 * @package WordPress

 * @subpackage AA_Custom_Theme

 * @since AA Custom Theme 1.0

 */

 global $dspace;

get_header(); $cm = new AaCustomMeta();?>

<div id="contact-holder">

    <section id="contact-top" class="contact-row">
    	 <div class="contact-detail-area">
    	 	<div class="row">
				<?php

				$cm = new AaCustomMeta();

				$meta = $cm->getList($post->ID, 'contact-details', 'ContactDetails'); // post id, custom meta id, custom meta field type

				$config = $meta['__config'];

				unset($meta['__config']);

				if(is_array($meta) && sizeof($meta)):

				foreach($meta as $cnt_details):

				?>
				
					<div class="contact-detail-row <?php echo "icon-".strtolower($cnt_details['icon']); ?> col-xs-12 col-md-6 col-lg-3 col-xl-3">

						<span class="fa"></span>

						<span class="contact-detail-row-data">

							<?php

							if(isset($cnt_details['value_1']) && strlen($cnt_details['value_1'])):

								echo $cnt_details['value_1'];

							endif;

							if(isset($cnt_details['value_2']) && strlen($cnt_details['value_2'])):

								echo '<br>'.$cnt_details['value_2'];

							endif;

							?>

						</span>

					</div>
					

				<?php

				endforeach;

				endif;

				?>
			</div>
		 </div>
    	 <div class="contact-item" id="contact-details-form">

                <?php

                while(have_posts()): the_post();

                    the_content();

                endwhile;
				
				$contactform = $cm->get($post->ID, 'contact-form', 'ContactForm');

				$config = $contactform['__config'];

				unset($contactform['__config']);
				if(isset($contactform['title']) && $contactform['title']!=""){
					echo "<h2>".$contactform['title']."</h2>";
				}
				
				if(isset($contactform['form']) && $contactform['form']!=""){
					echo "<div class='contact_gravity'>";echo do_shortcode('[gravityform id="'.$contactform['form'].'" title="false" description="false" ajax="true"]');echo "</div>";
				}

                ?>

            </div><!-- / contact item -->



    </section><!-- / contact top -->

    
	<?php 
	 $map = $cm->get($post->ID, 'google-map', 'GoogleMap'); // post id, custom meta id, custom meta field type



    if(isset($map['lat']) && strlen($map['lat']) && isset($map['long']) && strlen($map['long']) && isset($map['show']) && strtolower($map['show'])=='yes'):


		echo "<h2>FIND US ON MAP</h2>";
        echo '<div id="banner-map"></div>';






    endif;
	
	?>




</div><!-- / contact top -->

<?php get_footer(); ?>

