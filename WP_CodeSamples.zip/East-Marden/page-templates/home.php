<?php

/**

 * Template Name: Home

 *

 * @package WordPress

 * @subpackage AA_Custom_Theme

 * @since AA Custom Theme 1.0

 */



$cm = new AaCustomMeta();



get_header();  

$meta_boxes = get_post_meta($post->ID,'metabox_order',true);
$page_meta_boxes = unserialize($meta_boxes);

?>

    <!-- / home page -->

    <section id="home-page">
        <?php
		  $metaslider = $cm->get($post->ID, 'home_meta_slider', 'HomeMetaSlider');
		  //echo "<PRE>";print_r($metaslider);echo "</PRE>";
		  if(trim($metaslider['main_slider'])!=""){
			 echo "<div id='large_slider'>";
				echo do_shortcode($metaslider['main_slider']);
				echo '<div class="banner_arrow"><span></span></div>';
			  echo "</div>";
		  }
		  
		  if(trim($metaslider['mobile_slider'])!=""){
			 echo "<div id='device_slider'>";
				echo do_shortcode($metaslider['mobile_slider']);
			  echo "</div>";
		  }else if(trim($metaslider['main_slider'])!=""){ // if no mobile slider show the main slider itself.
			   echo "<div id='device_slider'>";
				echo do_shortcode($metaslider['main_slider']);
			  echo "</div>";
		  }
		  
		  /*echo "<div id='device_slider'>";
			echo do_shortcode("[metaslider id=818]");
		  echo "</div>";*/
	?>
		
        <!-- end -->
		<div style="min-height:500px;">
			<?php
				include_once(get_stylesheet_directory().'/homecontent/quicklinks.php');
				include_once(get_stylesheet_directory().'/homecontent/aboutus.php');				
				include_once(get_stylesheet_directory().'/homecontent/newsFeed.php');			
				include_once(get_stylesheet_directory().'/homecontent/specialProgram.php');			
				include_once(get_stylesheet_directory().'/homecontent/enroll-events.php');	
				include_once(get_stylesheet_directory().'/homecontent/studentVoice.php');
				include_once(get_stylesheet_directory().'/homecontent/partners.php');
			?>
        </div>
    </section>

<?php get_footer();