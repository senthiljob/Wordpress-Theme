<?php

function child_css_variables(){
	wp_enqueue_style('child-css-variables', get_stylesheet_directory_uri().'/css/variables.css');
}
add_action('wp_enqueue_scripts', 'child_css_variables',20);

function theme_enqueue_styles() {

    $parent_style = 'parent-style';
    $parent_main_style = 'parent-main-style';

    //wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );    
	//wp_enqueue_style( $parent_main_style, get_template_directory_uri() . '/css/main.css' );
    //wp_enqueue_style('child-css-variables', get_stylesheet_directory_uri().'/css/variables.css');
    wp_enqueue_style( 'child-style',get_stylesheet_directory_uri() . '/style.css');
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 9999 );

function childloadScripts()
	{
        wp_register_script('smoothscroll', get_stylesheet_directory_uri().'/js/smoothScroll.js', array('jquery'), false, 1);
		wp_enqueue_script('smoothscroll');
		wp_register_script('scrollreveal', get_stylesheet_directory_uri().'/js/scrollreveal.min.js', array('jquery'), false, 1);
		wp_enqueue_script('scrollreveal');
		wp_register_script('commonjs', get_stylesheet_directory_uri().'/js/common.js', array('jquery'), false, 1);
		wp_enqueue_script('commonjs');
		wp_register_script('translate-js', '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit', array('jquery'), false, 1);
		wp_enqueue_script('translate-js');
		wp_register_script('cookie-js', get_stylesheet_directory_uri().'/js/jquery.cookie.min.js', array('jquery'), false, 1);
		wp_enqueue_script('cookie-js');

		
	}

add_action('wp_enqueue_scripts', 'childloadScripts',20);


function add_custom_meta_boxes_on_child() {

		# QuickLinks
		$cm = new AaCustomMeta();
		$cm->id = 'quicklinks';
		$cm->name = 'QuickLinks';
		$cm->fieldType = 'QuickLinks';
		$cm->repeatable = 1;
		$cm->childField = 1;
		$cm->limit = 5;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# About Us
		$cm = new AaCustomMeta();
		$cm->id = 'aboutus';
		$cm->name = 'AboutUs';
		$cm->fieldType = 'AboutUs';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# Promo 1 - Special Program
		$promo1_title = "";
		$cm = new AaCustomMeta();
		$cm->id = 'promo1';
		$cm->name = 'Promo 1'.(isset($_GET['post']) && $_GET['post']!="" ? " - ".get_post_meta($_GET['post'],$cm->prefix.'promo1_title',true): "");
		$cm->fieldType = 'Promo1';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# Promo 2 - Curriculuam
		$cm = new AaCustomMeta();
		$cm->id = 'promo2';
		$cm->name = 'Promo 2'.(isset($_GET['post']) && $_GET['post']!="" ? " - ".get_post_meta($_GET['post'],$cm->prefix.'promo2_title',true): "");
		$cm->fieldType = 'Promo2';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# Promo 3 - Enroll 
		$cm = new AaCustomMeta();
		$cm->id = 'promo3';
		$cm->name = 'Promo 3'.(isset($_GET['post']) && $_GET['post']!="" ? " - ".get_post_meta($_GET['post'],$cm->prefix.'promo3_title',true): "");
		$cm->fieldType = 'Promo3';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# Promo 4 - Event 
		$cm = new AaCustomMeta();
		$cm->id = 'promo4';
		$cm->name = 'Promo 4'.(isset($_GET['post']) && $_GET['post']!="" ? " - ".get_post_meta($_GET['post'],$cm->prefix.'promo4_title',true): "");
		$cm->fieldType = 'Promo4';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# Promo 5 - Student Events
		$cm = new AaCustomMeta();
		$cm->id = 'promo5';
		$cm->name = 'Promo 5'.(isset($_GET['post']) && $_GET['post']!="" ? " - ".get_post_meta($_GET['post'],$cm->prefix.'promo5_title',true): "");
		$cm->fieldType = 'Promo5';
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();

		# sponsors
		$cm = new AaCustomMeta();
		$cm->id = 'sponsors';
		$cm->name = 'Sponsors';
		$cm->fieldType = 'Sponsors';
		$cm->repeatable = 1;
		$cm->childField = 1;
		$cm->show = array('home.php','homefixedbanner.php');
		$cm->place();
	
	
}
add_action('admin_init', 'add_custom_meta_boxes_on_child');

function custom_login_styles() {
		echo '<link rel="stylesheet" href="'.get_stylesheet_directory_uri().'/admin/login.css" media="all" />';
	}
add_action('login_head', 'custom_login_styles');

function formatbytes($filesize, $type)
{
	
   if($filesize=='') return "";
   switch(strtoupper($type)){
      case "KB":
         $filesize = $filesize * .0009765625; // bytes to KB
      break;
      case "MB":
         $filesize = ($filesize * .0009765625) * .0009765625; // bytes to MB
      break;
      case "GB":
         $filesize = (($filesize * .0009765625) * .0009765625) * .0009765625; // bytes to GB
      break;
   }
   
   if($filesize <= 0){
      return $filesize = 'unknown file size';}
   else{return round($filesize, 1).' '.$type;}
}


function get_header_class_on_banner(){
	if(!is_front_page()){
		global $bannerTitle,$post;
		switch(get_post_type()):
			case 'post':
					if(is_single()):
						if(!isset($cm)):
							$cm = new AaCustomMeta();
						endif;
			
						$banner = $cm->get($post->ID, 'post_banner', 'Banner'); // post id, custom meta id, custom meta field type
						if(isset($banner['image']) && strlen($banner['image'])):
							$bannerImage = $banner['image'];
						endif;
					endif;
				break;
			case 'page':
				   if(!isset($cm)):	
						$cm = new AaCustomMeta();		
					endif;
			
					$banner = $cm->get($post->ID, 'banner', 'Banner'); // post id, custom meta id, custom meta field type	
			
			
					if(isset($banner['image']) && strlen($banner['image'])):
			
						$bannerImage = $banner['image'];
			
					endif;
			
					if(isset($banner['mobile_image']) && strlen($banner['mobile_image'])):
			
						$mobileBannerImage = $banner['mobile_image'];
					endif;
			break;
		endswitch;
		$header_class='no-banner-header';
		
		if(isset($banner)):
			if((isset($bannerImage) && strlen($bannerImage)) || (isset($mobileBannerImage) && strlen($mobileBannerImage))):
				$header_class='with-banner-header'; 
			endif;
			if(!isset($mobileBannerImage)){
				$header_class.=' no-mobile-banner'; 
			}
		endif;
		return $header_class;
	}
	return "";
}

add_filter('body_class', 'add_custom_body_class');

function add_custom_body_class($classes) {
        $classes[] = get_header_class_on_banner();
        return $classes;
}


function form_submit_button($button,$form){
	$form_title = sanitize_title($form['title']);
	//return '<input type="submit" class="gform_button btn '.$form_title.'" id="gform_submit_button_' . $form['id'] . '" value="Send Message">';
	return '<button type="submit" class="gform_button btn '.$form_title.'" id="gform_submit_button_' . $form['id'] . '">Send Message</button>';
}
add_filter('gform_submit_button_1','form_submit_button',10,2);


/**
 * Fix Gravity Form Tabindex Conflicts
 * https://gravitywiz.com/fix-gravity-form-tabindex-conflicts/
 */
add_filter( 'gform_tabindex', 'gform_tabindexer', 10, 2 );
function gform_tabindexer( $tab_index, $form = false ) {
    $starting_index = 1000; // if you need a higher tabindex, update this number
    if( $form )
        add_filter( 'gform_tabindex_' . $form['id'], 'gform_tabindexer' );
    return GFCommon::$tab_index >= $starting_index ? GFCommon::$tab_index : $starting_index;
}


add_filter('theme_settings_tab', 'custom_theme_tab',10);

function custom_theme_tab($tabs){
	 $header_popup_offset = 0;
	 $header_popup = array(

	                 array('name'=>'Active', 'callback'=>'yesNo'),

	                 array('name'=>'Text', 	'callback'=>'text'),

	                 array('name'=>'Icon',	'callback'=>'image', 	'args'=> array('img'=>array('width'=>21, 'height'=>21)))
	        );
 
	$tabs['Alerts / Popups'] = array_slice($tabs['Alerts / Popups'], 0, $header_popup_offset, true) +
            array('Header Alert' => $header_popup) +
            array_slice($tabs['Alerts / Popups'], $header_popup_offset, NULL, true);

	return $tabs;
}