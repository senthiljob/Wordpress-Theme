<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage AA_Custom_Theme
 * @since AA Custom Theme 1.0
 */
global $dspace,$left_sidebar,$right_sidebar,$post,$c_post_type;
include(get_template_directory().'/inc/page-controls.php');
$tname = basename(get_page_template());

if(trim($left_sidebar)!="") $showLeft = 1;
if(trim($right_sidebar)!="") $showRight = 1;

if(isset($post) && isset($post->post_type) && (is_post_type_archive('team_profile') || $post->post_type == 'team_profile')) {
    $showRight = 0;$showLeft = 0;
}


if($dspace->template == 'table-of-contents.php' || $dspace->template == 'table-of-contents-manual.php'  || $c_post_type=="tribe_events" || is_post_type_archive("team_profile")){
            $showRight = 0; $showLeft = 0;
}

?>

<?php if (!is_front_page() && $tname!="homefixedbanner.php"): ?>
                        </div><!-- / body content -->
    <?php 
    	if($tname != 'searchpage.php'):
	    	$sharing_show = $dspace->settings->getOptions('Social Media','Sharing','Share Placement');
	        if($sharing_show=="Bottom") {
	        	include(get_template_directory().'/inc/add-this.php');
	        }

	    	if (!is_search() && $dspace->template != 'table-of-contents.php' && !is_post_type_archive('team_profile') && $post->post_type != 'team_profile'):     	    
	    		include(get_template_directory() . '/inc/content-footer.php');
	    	endif;
	    endif;
    
    if (isset($post->ID) && !is_search()):
        $cm = new AaCustomMeta();

        $cmId = 'page_related_content';
        $cmKey = 'PageRelatedContent';

        $related = $cm->getList($post->ID, $cmId, $cmKey);
        $config = $related['__config'];
        unset($related['__config']);

        $width = isset($config['image']['args']['width']) ? $config['image']['args']['width'] : 400;
        $height = isset($config['image']['args']['height']) ? $config['image']['args']['height'] : 240;
		
		$related_content = $dspace->settings->getOptions('General','Site Default'); 
		//echo "<PRE>";print_r($related_content);echo "</PRE>";
		$page_related_title = $cm->get($post->ID,'page_related_content_title','PageRelatedContentTitle');
    endif;
	

    if (isset($related) && is_array($related) && sizeof($related) && (isset($related[0]["image"])) && $related[0]["image"]!=""  && $page_related_title['enabled'] !="No"):
		
		$related_title = '';
		if(isset($related_content['related_content_title']) && $related_content['related_content_title']!=""){
			$related_title =$related_content['related_content_title'];
		}
		
		if(isset($page_related_title['heading']) && $page_related_title['heading']!=""){
			$related_title =$page_related_title['heading'];
		}
        ?>
        <section id="body-related-content">
			<!--<div  class="container nopadding">-->
				<div  class="row">
					<?php if($related_title!=""){ ?><div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><h3><?php echo $related_title; ?></h3></div><?php } ?>
					<?php
					$related_content_class = "col-xs-12 col-sm-6 col-md-4 col-lg-4";
					if($left_sidebar!="" && $showLeft==1){
						//$related_content_class = "col-xs-12 col-sm-6 col-md-6 col-lg-6"; 
					}
					foreach ($related as $r):
						echo '<div class="' . $related_content_class . ' releated-content-div">';
						unset($linkOpen);
						unset($linkClose);
						$target = (($r['target']=="Yes") ? "_blank" : "");
						if (isset($r['link']) && strlen($r['link'])):
							$linkOpen = '<a href="' . AaHelp::checkLink($r['link']) . '" target="'.$target.'">';
							$linkClose = '</a>';
						endif;

						echo '<figure>';
						if (isset($linkOpen)): echo $linkOpen; endif;

						$img = $r['image'];
						if (isset($img) && strlen($img)):
							$image = Imulation::open($img)
								->width(395)
								->height(240)
								->scale(Imulation::FIT)
								->crop()
								->save('related-image')
								->filename();
							$image = $image->url;
							if (file_exists(ABSPATH . '/' . $image)):
								echo '<img class="img-responsive" src="' . AaHelp::checkLink($image) . '">';
							endif;
						endif;

						if (isset($linkOpen)): echo $linkClose; endif;
						echo '</figure>';

						echo '<div class="related-block-content">';

						if (isset($r['heading']) && strlen($r['heading'])):
							echo '<div class="cont">';
							if (isset($linkOpen)): echo $linkOpen; endif;
							echo strip_tags($r['heading']) ;
							echo '</div>';
							if (isset($linkOpen)): echo $linkClose; endif;

							if(isset($r['description'])){
								echo '<div class="brief">';
								echo strip_tags($r['description']) ;
								echo '</div>';								
							}
						endif;

						echo '</div>';
						echo '</div>';
					endforeach;
					?>
				</div>
			<!--</div>-->
        </section><!-- / body related content -->
    <?php
    endif;
    ?>
					</div><!-- / content -->
                    
                     <?php if($right_sidebar && $showRight==1):
						echo '<div id="right-column"  class="d-none d-lg-block col-md-3"><div class="row">'.$right_sidebar.'</div></div>';
					 endif; 
					?>
                   <?php if((isset($right_sidebar) && $right_sidebar && $showRight==1) || ($showLeft==0)): echo "</div>"; endif; ?>
				</div><!-- / content area  -->
                 <?php if((isset($right_sidebar) && $right_sidebar && $showRight==1) || ($showLeft==0)): echo "</div>"; endif; ?>
			  </div><!-- / content holder -->
           </div>
		</div><!-- / holder -->
        <?php 
			$postType = get_post_type();
		   // AaHelp::trace($post);
			$category_sidebar_show = array();
			$page_sidebar_show = array();
			if(is_category()):
				$wp_session['category'] = get_category(get_query_var('cat'));
			endif;
			if(is_single() ):
					$wp_session = $_SESSION;
			endif;
			 if(is_home() && isset($post->ID)){
				 $blog_id = get_option( 'page_for_posts');
				 $category_sidebar_show = explode("_",get_post_meta($blog_id,'category_navigation',true));
				 $page_sidebar_show = explode("_",get_post_meta($blog_id,'page_navigation',true));
			 }else if(get_post_type() == 'post' && isset($post->ID)){
				 
					if(isset($wp_session['category']->term_id)):
						$category = $wp_session['category'];
					else:
						$category = get_the_category($post->ID);
						if(isset($category[0])):
							$category = $category[0];
						endif;
					endif;
					
					$categoryOptions = [];
					if(isset($category->term_id)):
						$categoryOptions = get_option('category_'.$category->term_id);
						$category_sidebar_show = explode("_",$categoryOptions['Category Navigation']);
						$page_sidebar_show = explode("_",$categoryOptions['Page Navigation']);
					endif;
			 
			 }else if(get_post_type() == 'page' && isset($post->ID)){
					
					$category_sidebar_show = explode("_",get_post_meta($post->ID,'category_navigation',true));
					$page_sidebar_show = explode("_",get_post_meta($post->ID,'page_navigation',true));
			 }
			 
			ob_start();
        
            dynamic_sidebar('lowernav');
        
            $lower_navigation = ob_get_clean();
			if(trim($lower_navigation)!=""):
		?>
		<div class="container">
			<?php //if(in_array('Lower Navigation',$page_sidebar_show)) include(get_template_directory() . '/inc/sub-menu.php'); ?>
			<?php echo $lower_navigation;//include(get_template_directory() . '/inc/sub-menu.php');?>
		</div>
<?php endif; endif; ?>
	 </section><!-- / body -->
    
</div><!-- wrap -->
<div id="footer">
	 <?php if($dspace->config->fatfooter=='Yes'):
	 		$total_footer = 0;
			for ($i=1; $i<=4; $i++){
				$footer='footer'.$i;
				if(is_active_sidebar( $footer )){
					$total_footer++;
				}
			}
			$md_lg_size = 1;
			if($total_footer > 0){
				$md_lg_size = 12 / $total_footer;
			}
			if($total_footer )
	  ?>
        <div id="footer-content" class="holder">
            <div class="container">
                <div class="row">
                    <?php
                    for ($i=1; $i<=4; $i++){
                        $footer='footer'.$i;
                        $sm_class = 4;

                        if($total_footer == 4) $sm_class = 6;
                        if($total_footer == 2) $sm_class = 6;
                        if($total_footer == 3) $sm_class = 4;
                        if($total_footer == 1) $sm_class = 12;
                        $single_col = '';
                        if($total_footer == 1) {
                        	$single_col = 'clsSingleCol';
                        }
                        //if($i == 1) $sm_class = '12';

                        ob_start();
                        dynamic_sidebar($footer);
                        $footerx = ob_get_clean();
                        if(trim($footerx)!=""){
                    ?>	
                    <!-- / col-xs-12 col-sm-6 col-lg-3 -->
                    <!-- / col-xs-12 col-sm-7 col-lg-9 nopadding-right -->
	                    <div class="col-xs-12 col-md-<?php echo $sm_class; ?> col-lg-<?php echo $md_lg_size; ?> <?php echo $single_col; ?>">
	                        <?php 
	                        	echo $footerx;
	                         ?>
	                    </div>
                    <?php 
                     }
                    }
                    ?>
                </div><!--/ row -->
            </div><!-- / container -->
        </div><!-- / footer-content -->
    <?php endif; ?>	
    	<!-- / footer-content -->
	<?php
		// site navigation goes here
		$menu = new AaMenu('Footer Menu');
		$menu->depth = 1;
		$menu->menuOpener = '<ul>';
		$menu->menuCloser = '</ul>';
		$menu->itemOpener = '<li%c>';
		$menu->itemCloser = '</li>';
		$footer_menu_copy = $menu->menu();
	?>
    	
	<footer id="footer-credits">
		<!--- For tablet and desktop --->
		<div class="container d-none d-xs-none d-sm-none d-md-block d-lg-block d-xl-block">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="footer-credits-menu">
						<div class="footer_emps">©  2019 East Marden Primary School</div>
						<div class="footer_menu"><?php echo $footer_menu_copy; ?></div>
					</div>
				</div>	
			</div>
		</div><!-- / container -->
		<!--- For mobile --->
		<div id="footer-credits-mobile-1" class="d-block d-md-none d-lg-none d-xl-none">
			<div class="footer_emps col-xs-12 col-sm-12 col-md-12">©  2019 East Marden Primary School</div>
			<div class="footer-credits-menu col-xs-12 col-sm-12 col-md-12"><?php echo $footer_menu_copy; ?></div>
		</div>		
	</footer>
</div><!-- / footer -->
<?php wp_footer(); 

    if($dspace->template == 'contact.php'):
          if(!isset($cm)):
            $cm = new AaCustomMeta();
        endif;
        $map = $cm->get($post->ID, 'google-map', 'GoogleMap'); // post id, custom meta id, custom meta field type
	 if(isset($map['lat']) && strlen($map['lat']) && isset($map['long']) && strlen($map['long']) && isset($map['show']) && strtolower($map['show'])=='yes'):  
		 $lat=$map['lat'];     
		 $long=$map['long'];				
		 if(isset($map['marker']) && strlen($map['marker'])):           
		 	$marker = wp_get_attachment_url($map['marker']);		
		 else:              
			 $marker = '';  
		 endif;
				
			?>
            <script language="javascript">
					var map;
	
					function mapInitialize() {
						 var mapDiv = document.getElementById('banner-map');
						 map = new google.maps.Map(mapDiv, {
							center: {lat: <?php echo $lat; ?>, lng: <?php echo $long; ?>},
							zoom: 16,
							disableDefaultUI: true
						});
						addMarker();
					}
					function addMarker() {
					  var marker = new google.maps.Marker({
						position: new google.maps.LatLng(<?php echo $lat; ?>,<?php echo $long; ?>),
						icon: "<?php echo $marker; ?>",
						map: map,
						title: '<?php echo get_bloginfo('title'); ?>'
					  });
					}
			</script>
            
		  <?php $gmapapi = $dspace->settings->getOptions('Config'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $gmapapi['google_maps']['google_map_api'];?>&callback=mapInitialize"  async defer></script>
                 <?php

        endif;
    endif;
	
	


if (trim($dspace->config->trackBeforeBodyTag)!=""):
    echo $dspace->config->trackBeforeBodyTag;
endif;

?>
<div class="floating_social_icons">
 <?php                            
  include(get_template_directory().'/inc/social.php'); 
  ?>
</div>
</body>

</html>