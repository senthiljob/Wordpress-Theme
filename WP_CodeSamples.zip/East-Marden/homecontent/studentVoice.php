<?php $promo5 = $cm->get($post->ID, 'promo5', 'Promo5',"1");
    $promo5_config = $promo5['__config'];unset($promo5['__config']);
    //echo '<PRE>';print_r($promo5_config); echo '</PRE>';
    //echo '<PRE>';print_r($promo5); echo '</PRE>';
  

    if($promo5['enabled']!="No"):
        if(isset($promo5['image']) && strlen($promo5['image'])):
            $width = isset($promo5_config['image']['args']['width']) ? $promo5_config['image']['args']['width'] : 21;
            $height = isset($promo5_config['image']['args']['height']) ? $promo5_config['image']['args']['height'] : 21;
            $student_voice_image = "";
            $image = Imulation::open($promo5['image'])
                ->width($width)
                ->height($height)
                ->scale(Imulation::FIT)
                ->save('student-image')
                ->filename();

            $image = $image->url;

            if(file_exists(ABSPATH.'/'.$image)):
                $image = AaHelp::checkLink($image);                           
                 $student_voice_image = $image;
            endif;
                    
        endif;

        $link = AaHelp::checkLink($promo5['read_more_link']);
?>
    <section class="student_bg" id="parents">

            <div class="container">

                <div class="row student_outer_box">

                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 student_img_box">

                        <img src="<?php echo $student_voice_image; ?>"/>

                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 student_cnt_box bottom">

                        <div class="content_header_box curriculam_header_box">

                            <h4><?php echo $promo5['title']; ?></h4>



                            <div class="clear"></div>

                        </div>

                        <?php echo apply_filters('the_content',$promo5['text']);?>



                        <div class="readmore_btn_box">

                            <a href="<?php echo $link; ?>" class="readmore_btn"><?php echo $promo5['read_more']; ?></a>

                        </div>

                    </div>

                </div>

            </div>

    </section>
<?php endif; ?>