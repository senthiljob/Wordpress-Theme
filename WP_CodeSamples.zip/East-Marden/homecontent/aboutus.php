<?php $aboutus = $cm->get($post->ID, 'aboutus', 'AboutUs',"1");
			 	$aboutus_config = $aboutus['__config'];unset($aboutus['__config']);
                //echo '<PRE>';print_r($aboutus); echo '</PRE>';
				if($aboutus['enabled'] == 'Yes'):
					$principal_bg = '';
					
					if(isset($aboutus['principal_image']) && strlen($aboutus['principal_image'])):
						$width = isset($aboutus['principal_image']['args']['width']) ? $aboutus_config['principal_image']['args']['width'] : 185;
           				$height = isset($aboutus['principal_image']['args']['height']) ? $aboutus_config['principal_image']['args']['height'] : 222;

                        $image = Imulation::open($aboutus['principal_image'])

                            ->width($width)
                            ->height($height)
                            ->scale(Imulation::FILL)
                            ->crop()
                            ->save('principal-image')
                            ->filename();

                        $image = $image->url;

                        if(file_exists(ABSPATH.'/'.$image)):
                            $image = AaHelp::checkLink($image);                           
							 $principal_bg = $image;
                        endif;
					
                    endif;

                    
                  
					
			?>
            <section class="creativity_bg">

            <div class="container">

                <div class="creativity_outer_box">

                    <div class="creativity_left_box">

                        <div class="creativity_respect_box left">

                            <div class="boldTitle">
                                <?php echo str_replace("", "<br/>", $aboutus['main_title']); ?>
                            </div>

                        </div>

                        <div class="pricipal_img_box bottom">

                            <img src="<?php echo $principal_bg; ?>"/>

                            <div class="pricipal_details_box">

                                <h6><?php echo $aboutus["principal_name"]; ?></h6>

                                <p class="creativity_para">Principal</p>

                            </div>

                        </div>

                    </div>

                    <div class="creativity_right_box bottom ">

                        <h5 class="common_h5 "><?php echo $aboutus["title"]; ?></h5>

                        <?php echo apply_filters('the_content',$aboutus["message"]); ?>                        

                        <div class="readmore_btn_box ">

                            <a target="<?php echo ($aboutus['target'] == 'Yes' ? '_blank' : '');?>" href="<?php echo AaHelp::checkLink($aboutus["link"]); ?>" class="readmore_btn">
                                <?php echo $aboutus["link_text"]; ?>                                
                            </a>

                        </div>

                    </div>

                    <div class="clear"></div>

                </div>

            </div>

        </section>

        	<?php endif; ?>
 