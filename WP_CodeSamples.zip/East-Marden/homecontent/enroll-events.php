<?php $promo3 = $cm->get($post->ID, 'promo3', 'Promo3',"1");
    $promo3_config = $promo3['__config'];unset($promo3['__config']);

$promo4 = $cm->get($post->ID, 'promo4', 'Promo4',"1");
    $promo4_config = $promo4['__config'];unset($promo4['__config']);    
//echo '<PRE>';print_r($promo4); echo '</PRE>';
?>
    <section class="enrolling_bg" id="enrollment">

            <div class="container">

                <div class="row program_outer_box">
                  <?php if($promo3['enabled'] !="No"):

                    if(isset($promo3['file_icon']) && strlen($promo3['file_icon'])):
                            $width = isset($promo3_config['file_icon']['args']['width']) ? $promo3_config['file_icon']['args']['width'] : 20;
                            $height = isset($promo3_config['file_icon']['args']['height']) ? $promo3_config['file_icon']['args']['height'] : 20;
                            $icon_image = "";
                            $image = Imulation::open($promo3['file_icon'])
                                ->width($width)
                                ->height($height)
                                ->scale(Imulation::FIT)
                                ->save('icon-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                 $icon_image = $image;
                            endif;
                                    
                    endif;


                    ?>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 program_box curriculam_box ">

                        <div class="bottom">

                            <div class="content_header_box curriculam_header_box">

                                <a href="<?php echo AaHelp::checkLink($promo3["title_link"]) ?>" >
                                    <h4><?php echo $promo3["title"]; ?>
                                        <span class="arrow_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/blue_arrow_icon.png"/></span>
                                    </h4>
                                </a>
                                <div class="clear"></div>

                            </div>

                            <?php echo apply_filters('the_content',$promo3['text']); ?>

                            <div class="download_box">

                                <a href="<?php echo wp_get_attachment_url( $promo3['file'] ); ?>" target="_blank">

                                    <span><img src="<?php echo $icon_image; ?>"/></span>
                                    <?php 
                                        $file_size = filesize(get_attached_file( $promo3['file'])); 
                                    ?>
                                    <span class="filename"><?php echo $promo3["file_name"];?> (<?php echo formatSizeUnits($file_size);?>)</span>

                                </a>

                            </div>



                            <div class="readmore_btn_box">

                                <a href="<?php echo AaHelp::checkLink($promo3["read_more_link"]);?>" class="readmore_btn"><?php echo $promo3["read_more"];?></a>

                            </div>



                        </div>

                    </div>

                <?php endif; ?>
                <?php if($promo4['enabled'] !="No"):
                    if(isset($promo4['image']) && strlen($promo4['image'])):
                            $width = isset($promo4_config['image']['args']['width']) ? $promo4_config['image']['args']['width'] : 488;
                            $height = isset($promo4_config['image']['args']['height']) ? $promo4_config['image']['args']['height'] : 488;
                            $promo4_image = "";
                            $image = Imulation::open($promo4['image'])
                                ->width($width)
                                ->height($height)
                                ->scale(Imulation::FIT)
                                ->save('event-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                $promo4_image = $image;
                            endif;
                                    
                    endif;
                    ?>
                    <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12 enrolling_img_box">

                        <div>
                            <img src="<?php echo $promo4_image; ?>"/>
                        </div>

                    </div>



                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 program_box special_program_box openday_box bottom">

                        <div class="content_header_box program_header_box clspaddingtopbottomnone">

                            <h4><?php echo str_replace(" ","<br/>",$promo4["title"]); ?><span><?php echo $promo4["promo_date"]; ?></span> <span><?php echo $promo4["promo_time"]; ?></span></h4>

                            <!--<span class="arrow_icon"><img src="images/white_arrow.png"/></span>-->

                            <div class="clear"></div>

                        </div>

                        <?php echo apply_filters('the_content',$promo4['text']); ?>



                        <div class="readmore_btn_box enquirynow_box">

                            <a href="<?php echo AaHelp::checkLink($promo4['read_more_link']); ?>" class="readmore_btn">
                                <?php echo $promo4['read_more']; ?>                                    
                            </a>

                        </div>

                    </div>
                <?php endif; ?>
                </div>

            </div>

        </section>