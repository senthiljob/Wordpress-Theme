<?php $sponsors = $cm->getList($post->ID, 'sponsors', 'Sponsors',"1");
    $sponsors_config = $sponsors['__config'];unset($sponsors['__config']);
    //echo '<PRE>';print_r($sponsors); echo '</PRE>';
    
?>
    <section class="partner_bg">

            <div class="container">

                <div class="partner_list_box">

                    <ul class="logoSlider" >
                        <?php foreach($sponsors as $partners):
                        $link = AaHelp::checkLink($partners['link']);
                        $target = $partners['target'];
                            if(isset($partners['image']) && strlen($partners['image'])):
                                $partner_image = wp_get_attachment_url($partners['image']);                                         
                            endif;
                            ?>
                        <li>

                            <img src="<?php echo $partner_image; ?>" alt="list_logo">

                        </li>
                    <?php endforeach;?>
                    </ul>
                    <div class=center>
                        <a href="#" id="prev"><i class="fas fa-chevron-left"></i></a>
                        <a href="#" id="next"><i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>

            </div>

        </section>