<?php $promo1 = $cm->get($post->ID, 'promo1', 'Promo1',"1");
    $promo1_config = $promo1['__config'];unset($promo1['__config']);
    //echo '<PRE>';print_r($promo1); echo '</PRE>';
    
     $promo2 = $cm->get($post->ID, 'promo2', 'Promo2',"1");
    $promo2_config = $promo2['__config'];unset($promo2['__config']);

    //echo '<PRE>';print_r($promo2); echo '</PRE>';
?>
    <section class="program_bg">

            <div class="container">

                <div class="row program_outer_box">

                    <?php
                    if($promo1['enabled'] == 'Yes'):

                        if(isset($promo1['program1_image']) && strlen($promo1['program1_image'])):
                            $width = isset($promo1_config['program1_image']['args']['width']) ? $promo1_config['program1_image']['args']['width'] : 21;
                            $height = isset($promo1_config['program1_image']['args']['height']) ? $promo1_config['program1_image']['args']['height'] : 21;
                            $program1_image = "";
                            $image = Imulation::open($promo1['program1_image'])

                                ->width(12)
                                ->height($height)
                                ->scale(Imulation::FIT)
                                ->save('sp-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                 $program1_image = $image;
                            endif;
                                    
                        endif;

                        if(isset($promo1['program2_image']) && strlen($promo1['program2_image'])):
                            $width = isset($promo1_config['program2_image']['args']['width']) ? $promo1_config['program2_image']['args']['width'] : 21;
                            $height = isset($promo1_config['program2_image']['args']['height']) ? $promo1_config['program2_image']['args']['height'] : 21;
                            $program2_image = "";
                            $image = Imulation::open($promo1['program2_image'])

                                ->width(19)
                                ->height(19)
                                ->scale(Imulation::FIT)
                                ->save('sp-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                 $program2_image = $image;
                            endif;
                                    
                        endif;

                        if(isset($promo1['program3_image']) && strlen($promo1['program3_image'])):
                            $width = isset($promo1_config['program3_image']['args']['width']) ? $promo1_config['program3_image']['args']['width'] : 21;
                            $height = isset($promo1_config['program3_image']['args']['height']) ? $promo1_config['program3_image']['args']['height'] : 21;
                            $program3_image = "";
                            $image = Imulation::open($promo1['program3_image'])

                                ->width(19)
                                ->height(19)
                                ->scale(Imulation::FIT)
                                ->save('sp-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                 $program3_image = $image;
                            endif;
                                    
                        endif;
                    ?>

                    

                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" >

                        <div class="program_box special_program_box  program_first_box bottom">

                            <div class="content_header_box program_header_box clspaddingtopbottomnone">

                                <a href="javascript:void(0)">

                                    <h4>
                                        <?php echo str_replace(" ","<br/>",$promo1["title"]); ?>
                                        <span class="arrow_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/white_arrow.png"/></span>

                                    </h4>

                                </a>

                                <div class="clear"></div>

                            </div>

                            <p class="program_para margin_program_para">
                                <?php echo $promo1["text"];?>
                            </p>

                            <div class="program_list_box">

                                <ul>

                                    <li class="chess_icon" style="background-image:url('<?php echo $program1_image;?>');"><?php echo $promo1["program1"]; ?></li>

                                    <li class="basketball_icon" style="background-image:url('<?php echo $program2_image;?>');"><?php echo $promo1["program2"]; ?></li>

                                    <li class="netball_icon" style="background-image:url('<?php echo $program3_image;?>');"><?php echo $promo1["program3"]; ?></li>

                                </ul>

                            </div>

                        </div>

                    </div>
                <?php endif; ?>
                <?php
                    if($promo2['enabled'] == 'Yes'):  

                        if(isset($promo2['image']) && strlen($promo2['image'])):
                            $width = isset($promo2_config['image']['args']['width']) ? $promo2_config['image']['args']['width'] : 913;
                            $height = isset($promo2_config['image']['args']['height']) ? $promo2_config['image']['args']['height'] : 547;
                            $program2_image = "";
                            $image = Imulation::open($promo2['image'])

                                ->width($width)
                                ->height($height)
                                ->scale(Imulation::FIT)
                                ->save('cur-image')
                                ->filename();

                            $image = $image->url;

                            if(file_exists(ABSPATH.'/'.$image)):
                                $image = AaHelp::checkLink($image);                           
                                 $program2_image = $image;
                            endif;
                                    
                        endif;

                    ?>
                    <div class="curriculam_box_outer col-lg-4 col-xl-4 col-md-12 col-sm-12 col-12" >
                        <style>
                            .program_bg:after{
                                background-image:url('<?php echo $program2_image; ?>');
                            }
                        </style>
                        <div class="program_box curriculam_box ">

                            <div class="bottom">

                                <div class="content_header_box curriculam_header_box ">

                                    <a href="<?php echo AaHelp::checkLink($promo2['link']); ?>" ><h4><?php echo $promo2['title']; ?><span class="arrow_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/blue_arrow_icon.png"/></span></h4></a>

                                    <div class="clear"></div>

                                </div>

                                <p class="program_para margin_program_para ">
                                    
                                    <?php echo apply_filters('the_content',$promo2['text']); ?>
                                </p>

                            </div>

                        </div>

                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12" >

                        <div class="curriculam_img_box"></div>

                    </div>
                <?php endif; ?>
                </div>

            </div>

        </section>