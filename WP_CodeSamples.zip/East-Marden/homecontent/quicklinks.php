<?php 
$quickLinks = $cm->getList($post->ID, 'quicklinks', 'QuickLinks',"1");
					
$quickLinks_config = $quickLinks['__config'];unset($quickLinks['__config']);

//echo 'DXDDDD=<PRE>';print_r($quickLinks); echo '</PRE>';
?>

<section class="school_laerning_bg" id="learning">

			<div class="container">

				<div class="payment_list_box">

					<ul>

						<?php foreach($quickLinks as $quicklink):

							$quick_img = "";
							if(isset($quicklink['image']) && strlen($quicklink['image'])):
								$width = isset($quickLinks_config['image']['args']['width']) ? $quickLinks_config['image']['args']['width'] : 71;
								$height = isset($quickLinks_config['image']['args']['height']) ? $quickLinks_config['image']['args']['height'] : 62;
		
								$image = Imulation::open($quicklink['image'])
		
									->width($width)
		
									->height($height)
		
									->scale(Imulation::FILL)
		
									//->crop()
		
									->save('quicklink-image')
		
									->filename();
		
								$image = $image->url;
		
								if(file_exists(ABSPATH.'/'.$image)):
									$image = AaHelp::checkLink($image);                           
									 $quick_img = $image;
								endif;
							endif;
						?>

						<li class="bottom">
							<a href="<?php echo AaHelp::checkLink($quicklink['link']); ?>" target="<?php echo ($quicklink['target']=='Yes'?'_blank':''); ?>">
								<div class="payment_img_box" style="background-image:url('<?php echo $quick_img; ?>');"></div>

								<div class="payment_cnt_box">

									<h6><?php echo $quicklink['link_text'];?></h6>

								</div>
							</a>

						</li>
					<?php endforeach; ?>
						
					</ul>



				</div>

			</div>

		</section>
