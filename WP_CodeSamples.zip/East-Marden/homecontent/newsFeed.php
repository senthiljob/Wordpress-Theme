<?php
$args = array(
        'numberposts' => 3,
        'post_status' => array( 'publish' ),
		'relation' => 'OR', //default AND
	        array(
	            'key' => 'show_on_home_page',
	            'compare' => 'NOT EXISTS'
	        ),
	        array(
	            'key' => 'show_on_home_page',
	            'value' => '1',
	            'compare' => '='
	        ),  
        'orderby' => 'post_date',
        'order' => 'DESC'
    );
    $latest_news = wp_get_recent_posts($args);

 $upcoming_events = tribe_get_events( [ 
   'posts_per_page' => 3, 
   'start_date'     => 'now',
] );

 //echo '<PRE>';print_r($upcoming_events); echo '</PRE>';

    if((!empty($latest_news) && count($latest_news) > 0) || (!empty($upcoming_events) && count($upcoming_events) > 0)):
?>

<section class="news_bg" id="new_and_events">

			<div class="container">

					<div class=" row latset_outer_box">
					  <?php if(!empty($latest_news) && count($latest_news) > 0): ?>
						<div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12  latest_news_box ">

							<div class="content_header_box yellow_bg">
								<a href="<?php echo get_permalink( get_option( 'page_for_posts' ) ); ?>" >

									<h4 class="news_h4">

										Latest News

										<span class="arrow_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/white_arrow.png"/></span>

									</h4>
									<div class="clear"></div>

								</a>
							</div>

							<div class="news_cont_box">

								<?php foreach($latest_news as $n): 

									unset($link);
                                    $link = get_permalink($n['ID']);
                                    $cm = new AaCustomMeta();
                                    $faImage = $cm->get($n['ID'], 'post_thumbnail', 'PostThumb');                        
                                    $link = get_permalink($n['ID']);
                                    $img = '';

                                    if ($faImage['image']){
                                            $image = Imulation::open($faImage['image'])->width(600)->height(453)->scale(Imulation::FILL)->save('news-image')->filename();
                                              $image = $image->url;
								            if (file_exists(ABSPATH . '/' . $image)){
								                $img = AaHelp::checkLink($image);
								            }
								    }else{
								    	$post_default_img = $themeSettings->getOptions('General','Post Default','Post Image');
								    	$is_default_active = $themeSettings->getOptions('General','Post Default','Activate Default Post Image');
								    	$image = Imulation::open($post_default_img)->width(600)->height(453)->scale(Imulation::FILL)->save('news-image')->filename();
                                              $image = $image->url;
								            if (file_exists(ABSPATH . '/' . $image) && $is_default_active == 'Yes'){
								                $img = AaHelp::checkLink($image);
								            }								    
								    	
                                    }

                                    $content = "";

                                    $short_description = $cm->get($n['ID'], 'short_description', 'ShortDescription');

                                    if($short_description["short_desc"]!=""){
                                    	$content = $short_description["short_desc"];
                                    }else{
                                    	//$content = wp_trim_words($n["post_content"],"20","...");
                                    }

								?>

								<div class="news_cont_list_box">								

									<div class="news_details_box">

										<?php if($img!=""): ?>

										<div class="news_left_box">

											<a href="<?php echo $link; ?>">
												<img class="img-responsive" src="<?php echo $img; ?>">
											</a>

										</div>

									<?php endif; ?>

										<div class="news_details_right" style="<?php if($img==""): echo "width:100%;";endif; ?>">

											<a href="<?php echo $link; ?>" class="news_para">
												<?php echo $n['post_title']; ?>
											</a>
											<?php if($content!="") {?><p style="margin-top:4px;line-height: 20px;"><?php echo $content; ?></p><?php } ?>
											<?php
												$file_list = $cm->getlist($n['ID'], 'excerpt_file', 'File', false); // post id, custom meta id, custom meta field type
												if(isset($file_list['__config'])) {
													unset($file_list['__config']);
												}

												if(!empty($file_list)) : 
													$dir = wp_upload_dir();
													foreach($file_list as $k_file => $file):
														if(isset($file['file']) && strlen($file['file'])):
															$fileMeta = get_post_meta($file['file']);
															if(isset($fileMeta['_wp_attached_file'][0])):
																
																$fileUrl = $dir['baseurl'].'/'.$fileMeta['_wp_attached_file'][0];
																
																// add the image and file size
																$file_end = explode('/',$fileUrl);//end();
																$file_end = end($file_end);
																$title = isset($file['file_title']) && !empty($file['file_title']) ? $file['file_title'] : $file_end ;
																//echo "<strong>".$title."</strong>";

																$op = '<div class="excerpt-file"><a style="font-size:15px;" href="'.$fileUrl.'" target="_blank">'.$title.'</a></div>';
																if(function_exists('mimetypes_to_icons') ){
																	echo mimetypes_to_icons($op);
																}
																else {
																	echo $op;
																}	
																	
															endif;
														endif;
													endforeach;
												endif;
											?>											
											<p class="news_para date_para"><?php echo date("M d, Y",strtotime($n['post_date'])) ?></p>
										</div>

										<div class="clear"></div>

									</div>

								</div>
							<?php endforeach;?>

							</div>

						</div>
					<?php endif; ?>
					<?php 
						$event_url = get_site_url()."/events";
					?>
						<div class="events_box col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">

							<div class="content_header_box blue_bg">

								<a href="<?php echo $event_url; ?>" >

									<h4 class="event_h4">

										Upcoming Events

										<span class="arrow_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/white_arrow.png"/></span>

									</h4>



									<div class="clear"></div>

								</a>

							</div>
							<?php 
							  if(!empty($upcoming_events) && count($upcoming_events) > 0):
								foreach($upcoming_events as $events):
								$event_date = date("d",strtotime($events->event_date));
								$event_month = date("F",strtotime($events->event_date));
							?>
							<div class="news_cont_box news_cont_right">

								<div class="news_cont_list_box">

									<div class="date_time_box">

										<span class="event_date_span"><strong><?php echo $event_date; ?></strong> <?php echo $event_month; ?></span>

										<!--<span class="event_time_span">4.30 pm - 6.00 pm</span>-->

									</div>
									<?php
										$event_content = $events->post_title;
										if($events->post_content!=""){
											$event_content = wp_trim_words($events->post_content,10,"...");
										}

									?>
									<a href="<?php echo get_permalink($events->ID); ?>"><?php echo $event_content; ?></a>

								</div>

							</div>

						<?php endforeach;?>
						<?php else: ?>
					 		<h4 style="margin:20px 0;text-align: center;">No upcoming events</h4>
					 	<?php endif; ?>
						</div>
					 
					</div>

				</div>

</section>
<?php endif; ?>
