<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage AA_Custom_Theme
 * @since AA Custom Theme 1.0
 */
// sets variables and stuff for layout and content

global $dspace,$c_post_type,$isSingle;

include(get_template_directory().'/inc/page-controls.php');
$c_post_type = get_post_type();
$isSingle = is_single();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml" <?php if($dspace->showLeft): echo ' class="page-has-left"'; endif;?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- <meta property="fb:app_id" content="<?php //echo $dspace->config->facebook; ?>"/>-->


    <title><?php wp_title( '|', true, 'right' ); ?></title>

    
    
    <link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico?v=1" />
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-TileImage" content="<?php echo get_bloginfo('url'); ?>/mstile-144x144.png">


    <!--[if lt IE 9]>
    <script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
    <![endif]-->


   
    <!--<link href='https://fonts.googleapis.com/css?family=Gloria+Hallelujah' rel='stylesheet' type='text/css'>-->

    <?php
     
    wp_head();

    if(trim($dspace->config->trackBeforeHeadTag) != ''):
        echo $dspace->config->trackBeforeHeadTag;
    endif;


    ?>


<!-- <script>document.documentElement.className += ' wf-loading';</script>-->

<script src='https://www.google.com/recaptcha/api.js' defer></script>
</head>
<body <?php body_class(); ?>>

<?php
if(trim($dspace->config->trackAfterBodyTag) !=''):
    echo $dspace->config->trackAfterBodyTag;
endif;
?>

<?php if (!is_search() && $dspace->template != 'table-of-contents.php'): ?>

<div id="fb-root"></div>
<script>

(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&appId=<?php echo $dspace->config->facebook; ?>&version=v2.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

</script>
<?php endif; ?>
<?php  
$dspace->settings->getPopup();
$tname = basename(get_page_template());
$main_header_hgt = "120";

$search_location = $dspace->settings->getOptions('Header and Footer','Header','Search Location'); 
$menu_settings = $dspace->settings->getOptions('Header and Footer','Main Menu Flyout'); 

$top_popup = $dspace->settings->getOptions('Alerts / Popups','Header Alert'); 
//echo '<PRE>';print_r($top_popup); echo '</PRE>';

if($top_popup['active'] != 'No'):
    if(isset($top_popup['icon']) && strlen($top_popup['icon'])):
            $width = 21;
            $height = 21;
            $icon_image = "";
            $image = Imulation::open($top_popup['icon'])
                ->width($width)
                ->height($height)
                ->scale(Imulation::FIT)
                ->save('promo-icon')
                ->filename();

            $image = $image->url;

            if(file_exists(ABSPATH.'/'.$image)):
                $image = AaHelp::checkLink($image);                           
                 $icon_image = $image;
            endif;                    
    endif;


?>
<section class="header_bottom_bg yellow_header_top pop_hide">
                <div class="container-fluid">
                    <div class="row">
                        <p class="header_para">
                            <span class="implement_img"><img src="<?php echo $icon_image;?>"></span>
                            <span class="implement_para">
                                <?php echo $top_popup['text']; ?>
                            </span>
                            <span class="arrow_img">
                                <a id="top_promo_close">
                                    <img src="<?php echo get_stylesheet_directory_uri();?>/images/close_icon.png">
                                </a>
                            </span>
                        </p>
                    </div>
                </div>
</section>
<?php endif; ?>
<header id="header" class="clearfix header_bg myheader clsheader" style="<?php if($top_popup['active'] == 'No') echo "margin-top:0px;" ?>">
  <?php if($dspace->config->topheader=='Yes'): ?>
	<div class="top_header d-none d-xs-none d-sm-none d-md-block d-lg-block d-xl-block">
    	 <div class="container">
                 <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 nopadding">
                    	<div class="top_header_content">
                        <?php if($search_location == '' || $search_location =="Slim Header"): ?>
                            <aside class="header-search">
                                    <?php //get_search_form(); ?>
                                    <div class="nav_search">
                                        <a href="javascript:void(0);"></a>
                                    </div>
                             </aside> 
                        <?php endif; ?>
                             <aside id="header-social">
                             	<?php include(get_template_directory().'/inc/social.php'); ?>
                             </aside>                                                        
                             <?php
							// site navigation goes here
							$menu = new AaMenu('Top Menu');
							if ($menu){
							?>
							<aside class="top_menu">
								<?php
									$menu->depth = 2;
									echo $menu->menu();
									?>
							</aside>
							<?php } ?>
                        </div>
                    </div>
                 </div>
         </div>
    </div>
  <?php else:
        $main_header_hgt = "70";
  endif; ?>
	<div class="container-fluid" >
        <div class="<?php if($menu_settings['menu_type']=="Slim") echo "container"; else echo "container-fluid"; ?>">
                 <div class="row">
                    <?php if($menu_settings['menu_type']!="Slim") echo "<div class='container'>";?>
                    <div class="header_logo col-xs-12 col-sm-12 col-md-2 nopadding-left">
                        <figure id="logo">
                            <a href="<?php echo get_bloginfo('url'); ?>" style="background:url('<?php echo get_stylesheet_directory_uri().'/images/header_logo.svg';  ?>');"></a>
                        </figure><!-- / logo -->
                    </div><!-- / top left -->
                    <?php if($menu_settings['menu_type']!="Slim") echo "</div>";?>
                    <div class="header_list col-xs-12 col-sm-12 col-md-12 <?php if($menu_settings['menu_type']=="Slim") echo "col-lg-10 col-xl-10"; else echo "col-lg-12 col-xl-12 clsMarginTopNeg"; ?>">
                         <div class="row">
                            <div class="col-md-12 main-menu">
                                <div class="row">
                                    <div id="main-menu-trigger-small" class="menu-button d-block d-md-block d-lg-none d-xl-none"><i class="fa fa-bars" aria-hidden="true"></i></div>
                                    <nav id="mobile_nav" class="d-block d-md-block d-lg-none d-xl-none hideMobileMenu">
									<?php
                                        // site navigation goes here
                                        $menu = new AaMenu('Main Menu');
                                        $menu->depth = 3;
                                        echo $menu->menu();
                                        ?>
                                    </nav>
                                    <nav id="<?php if($menu_settings['menu_type']=="Slim") echo "nav"; else echo "full-nav"; ?>"  class="d-none d-sm-none d-md-none d-lg-block d-xl-block col-md-12 col-lg-12 col-xl-12 navbar navbar-expand-lg fr">
										<div class="menu_holder">											
											<?php
												// site navigation goes here
												$menu = new AaMenu('Main Menu');
												$menu->depth = 3;
                                                //echo '<PRE>';print_r($menu_settings); echo '</PRE>';
                                                if($menu_settings['menu_type']!="Slim"){
                                                    $menu->fullWidthMenu = 1;
                                                    $menu->mainMenu = 1;
                                                    if($menu_settings['menu_type']=="Widescreen - 2 level"){
                                                        $menu->depth = 3;
                                                    }else{
                                                        $menu->depth = 2;                                                        
                                                    }
                                                }
												echo $menu->menu();
												?>
											  <?php if($search_location =="Main Header"): ?>
												 <div class="nav_search">
													<a href="javascript:void(0);"></a>
													<!---<aside class="header-search">
														<?php //get_search_form(); ?>
													</aside> -->
												 </div>
											 <?php endif; ?>
										</div>
                                    </nav>
                                 </div>
                            </div>
                         </div>
                        
                    </div><!-- / top right -->
                </div><!-- / row -->
				
                
         </div>
     </div>
	 <div class="row search_container" style="top:<?php echo $main_header_hgt; ?>px;">
		<div class="container">
			<div class="col-xs-12 col-sm-12 col-md-12 nopadding-left">
				<aside class="header-search">
					<?php get_search_form(); ?>
				</aside> 
			</div>
		</div>
	</div>
</header><!-- / header -->

<div id="wrap" style="<?php if($top_popup['active'] == 'No') echo "margin-top:70px;" ?>">
			<?php
            
            if(!is_front_page() && $tname!="homefixedbanner.php"):?>
            
                <div class="page-top">
            		
                    <?php if($showPageBanner): include(get_template_directory().'/inc/page-banner.php'); endif; ?>
                    <?php if($showPageHeader): include(get_template_directory().'/inc/page-header.php'); endif; ?>
                    <?php if($showPageBanner): include(get_template_directory().'/inc/header-gallery.php'); endif; ?>
                </div>
                <?php
                if(get_post_type() == 'page' && isset($post->ID)):
                    $cm = new AaCustomMeta();
                    $index = $cm->get($post->ID, 'content-index','ContentIndex');
                    if(isset($index['content_index']) && $index['content_index'] > 1):
                        global $aaContentIndex;
                        echo '<nav id="content-index-nav" class="in-page-nav">
                                        <div class="holder">';
                        $aaContentIndex->getIndexMenu($index['content_index']);
                        echo    '</div><!-- / holder -->
                                    </nav>';
                    endif;
                endif;
                ?>
            
            <?php endif; ?>

		<?php
        $menu_class='';
        if(get_post_type() == 'page' && basename(get_page_template()) == 'menu.php'):
            echo '<div id="menu-header">';
            $menu_class='menu-holder';
        
            $tab=0;
            $taxonomy='menu-categories';
            $args = array(
                'hide_empty' => 0,
                'orderby'=>'ID',
                'parent' => 0,
            );
            $terms = get_terms($taxonomy, $args);
            foreach ($terms as $term):
                $tab++;
                $cur_tab_class=($tab==1?'current':'');
                $categoryOption = get_option('category_'.$term->term_id);
                if(isset($categoryOption['Image'])) {
                     $value = $categoryOption['Image'];
                     $img = '';
                    //echo "-------->".$value."<br/>";
                    //unset($image);
                    $image = Imulation::open($value)
                        ->width(50)
                        ->height(50)
                        ->scale(Imulation::FIT)
                        ->save('menucat-image')
                        ->filename();
                    $image = $image->url;
                    if(file_exists(ABSPATH.'/'.$image)):
                        $img = AaHelp::checkLink($image);
                    endif;
                }
                ?>
                <section  class="menu-item-header <?php echo $cur_tab_class?>" id="header-item-<?php  echo $term->term_id;?>">
                    <div ><?php if($img!=""): ?><img src="<?php echo $img;  ?>"><?php endif; ?><?php  echo $term->name;?></div>
                </section>
            <?php
            endforeach;
            echo '</div>';
        endif; ?>
		<?php 
            global $left_sidebar,$right_sidebar;
            $left_sidebar ='';
            $right_sidebar ='';
            
            ob_start();
        
            dynamic_sidebar('sidebar-left-column');
        
            $left_sidebar = ob_get_clean();
            
			if(trim($left_sidebar)!="") $showLeft = 1;
            
            
            ob_start();
        
            dynamic_sidebar('sidebar-right-column');
        
            $right_sidebar = ob_get_clean();
            
			if(trim($right_sidebar)!="") $showRight = 1;
        
        
        global $post;

        if(isset($post) && isset($post->post_type) && (is_post_type_archive('team_profile') || $post->post_type == 'team_profile')) {
            $showRight = 0;$showLeft = 0;
        }

        if($dspace->template == 'table-of-contents.php' || $dspace->template == 'table-of-contents-manual.php' || $c_post_type=="tribe_events" || is_post_type_archive("team_profile")){
            $showRight = 0; $showLeft = 0;
        }
        
         ?>
 		<?php //if((isset($post->ID) && get_post_meta($post->ID, 'show_sharing_optons', true) && basename(get_page_template()) != 'contact.php') || (get_post_type() != 'page' && get_post_type() != 'tribe_events')): echo ' class="page-has-sharing"'; endif; ?>
        <section id="body" >
            <?php if(!is_front_page() && $tname!="homefixedbanner.php"): ?>
            <div class="container<?php if($left_sidebar!="" && $showLeft==1): echo ' with-left'; endif;if($right_sidebar!="" && $showRight==1): echo ' with-right'; endif; echo ' '.$menu_class;?> ">		
            
            <div class="row">
            
                 <?php if($left_sidebar && $showLeft==1):   
                 		   echo '<div id="left-column" class="d-none d-lg-block col-md-3 col-md-3">';
						   echo '<div class="row">';
                    	   echo $left_sidebar;
                    	   echo '</div></div>';
                       endif;
					   
					   $inner_full_content = '';
					   $main_content_class = 'col-lg-12 ';
					   $no_padding_right = '';
					   if($left_sidebar && $showLeft==1): 
							$no_padding_right = ' nopadding-right ';
					   		$main_content_class = 'col-lg-9 ';
							$inner_full_content = 'col-lg-12 ';	
                       else :
                            $main_content_class = 'col-lg-12 nopadding ';
                       endif;

                       if($dspace->template == 'searchpage.php'){
                            $main_content_class = 'col-lg-12 nopadding';
                            $inner_full_content = 'col-lg-12 ';
                            $showLeft=0;
                            $showRight =0;
                       }
				 ?>
                 
                <div id="content-holder" class="<?php  echo $main_content_class . $no_padding_right; ?>">
                   <?php if((isset($right_sidebar) && $right_sidebar && $showRight==1) || ($showLeft==0)): echo "<div class='row1'>"; endif; ?>
                    <div id="content-area" class="<?php echo $inner_full_content . $no_padding_right; ?> <?php if(isset($right_sidebar) && $right_sidebar && $showRight==1): echo ' with-right'; endif; ?>">
                        <?php if((isset($right_sidebar) && $right_sidebar && $showRight==1) /*|| ($showLeft==0)*/): echo "<div class='row'>"; endif; ?>
							<?php  $cm = new AaCustomMeta();
                                    if(isset($post->ID))
                                     $page_content_banner = $cm->get($post->ID, 'page_content_banner','ContentBanner');
                            if(isset($page_content_banner['Content Banner']) && $page_content_banner['Content Banner']!=""):	 
                            ?>
                            <div id="content_banner">
                                <?php 
                                     
                                     echo "<img src='".wp_get_attachment_url( $page_content_banner['Content Banner'])."' />";
                                     echo "<div class='content_banner_overlay'>".$page_content_banner['banner_text']."</div>";
                                 ?>                	
                            </div>
                            <?php  endif;?>
                            <div id="content" class="<?php if(isset($right_sidebar) && $right_sidebar && $showRight==1): echo 'col-lg-9 '; else: echo 'col-md-12 nopadding'; endif; echo $no_padding_right; ?>">
                                 <div id="body-content" class="clearfix">
                                    <?php
                                    if(isset($index['content_index']) && $index['content_index'] > 1):
                                        echo $aaContentIndex->get_content_index($index['content_index']);
                                    endif;
                                    ?>
                                    <?php endif;  ?>
						
